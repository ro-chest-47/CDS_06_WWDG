/**
 * The mqttevent package contains event classes that belong to MQTT protocol (v3.1.1).
 * 
 * @author CCSLab, Konkuk University
 *
 */
package kr.ac.konkuk.ccslab.cm.event.mqttevent;