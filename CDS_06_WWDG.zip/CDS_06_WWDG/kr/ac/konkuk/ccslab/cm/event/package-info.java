/**
 * The event package contains CM events that CM entities send and receive to communicate with each other.
 * @author CCSLab, Konkuk University
 *
 */
package kr.ac.konkuk.ccslab.cm.event;