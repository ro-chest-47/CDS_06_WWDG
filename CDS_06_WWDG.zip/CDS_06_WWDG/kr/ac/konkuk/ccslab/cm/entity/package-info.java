/**
 * This package represents an entity used in CM.
 * 
 * @author CCSLab, Konkuk University
 *
 */
package kr.ac.konkuk.ccslab.cm.entity;